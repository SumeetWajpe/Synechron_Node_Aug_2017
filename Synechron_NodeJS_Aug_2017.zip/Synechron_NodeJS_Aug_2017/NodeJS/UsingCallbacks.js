function processResult(err,result){
    if(err){
        console.log('Error :' + err.message);
    }
    else  {
        console.log('The result is :  ' + result);
    }
}
function Multiplier(aNumber,callBackMethod){
if(aNumber % 2 == 0){
    setTimeout(function(){
       callBackMethod(null,aNumber * 10);
    },200);
}
else{
    setTimeout(function(){
        callBackMethod(new Error('U passed and odd input !'),null)        
    },200)
}
}
Multiplier(2,processResult);
Multiplier(11,processResult);
Multiplier(20,processResult);
console.log('Program ended !')
