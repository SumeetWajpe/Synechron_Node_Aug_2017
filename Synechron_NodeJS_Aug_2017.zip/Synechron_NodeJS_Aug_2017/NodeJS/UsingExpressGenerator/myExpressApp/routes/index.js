var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/products',function(req,res){

  // Get the MongoClient
  var MongoClient = mongodb.MongoClient;

  // define the mongo server config

  var url = "mongodb://localhost:27017/products";

  MongoClient.connect('url',function(err,db){
      var collection = db.collection('products');
      /// Find all products
      collection.find({}).toArray(function(err,result){
          if(err){
            console.log('Error : ' + err)
          }
          else if(result.length){
           // res.json(result);
           res.render('productlist',{
             productlist:result
           })
          }
          else{
            res.send('No Products found !')
          }
          db.close();
      });
  })

})

module.exports = router;
