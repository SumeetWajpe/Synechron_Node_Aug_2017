var PI = 3.14;

function Add(x,y){
    return x + y;
}

function Product(x,y){
    return x * y;
}

// module.exports.Pie = PI ;
// module.exports.Addition = Add;
// module.exports.Multiplication =Product;

module.exports = {
    Addition:Add,
    Multiplication:Product
}