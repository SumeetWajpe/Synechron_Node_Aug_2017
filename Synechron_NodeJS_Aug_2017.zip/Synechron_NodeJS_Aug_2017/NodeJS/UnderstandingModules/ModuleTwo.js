var modOne = require('./ModuleOne');

console.log(modOne.PI);
console.log(modOne.Addition(20,30));