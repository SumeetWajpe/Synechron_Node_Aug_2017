var express = require('express');
var bodyParser = require('body-parser');

var app = express();
var router = express.Router();
// router.route('/products').get(function(req,res){
//     var products = [
//         {Name:'Laptop',Price:30000},
//         {Name:'Mobile',Price:20000},
//         {Name:'TV',Price:50000}        
//     ];
//     res.json(products);
// });

// router.route('/products/:name').get(function(req,res){
//    var productName = req.params.name;
//    res.end('You requested for : ' + productName);
// });

router.route('/products/:from-:to').get(function(req,res){
    var products = [
        {Name:'Laptop',Price:30000},
        {Name:'Mobile',Price:20000},
        {Name:'TV',Price:50000} ,
        {Name:'Headset',Price:5000} ,   
        {Name:'Watch',Price:5000}  
    ];

    var rangeFrom = parseInt(req.params.from);
    var rangeTo = parseInt(req.params.to);
    res.json(products.slice(rangeFrom,rangeTo));
});


app.use('/api',router);

app.use(bodyParser.urlencoded({extended:false}));

app.get('/',function(req,res){
    var person = {
        Name:'Sumeet',
        Location:'Pune'
    }
        //res.send('<h1> Hello Express ! </h1>');
        res.sendFile('Client.html',{root:__dirname});
        //res.json(person);
});

app.post('/login',function(req,res){
        console.log('Welcome ' + req.body.username);
        res.send('success'); // redirect to successful login !
})

app.use(function(req,res){
    res.writeHead(404);
    res.end('Resource Not Found !');
})


app.listen(4000,function(){
    console.log('server running @ 4000 !')
});
